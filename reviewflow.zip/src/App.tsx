import React from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider } from './context/AuthContext';
import { ToastProvider } from './context/ToastContext';

// Protected Route Guard
import { ProtectedRoute } from './components/auth/ProtectedRoute';

// Layouts
import { DashboardLayout } from './components/layout/DashboardLayout';
import { AdminLayout } from './components/layout/AdminLayout';

// Public Pages
import { LandingPage } from './pages/public/LandingPage';
import { LoginPage } from './pages/public/LoginPage';
import { SignupPage } from './pages/public/SignupPage';
import { ForgotPasswordPage } from './pages/public/ForgotPasswordPage';
import { PublicReviewPage } from './pages/public/PublicReviewPage';

// Legal & Compliance Pages
import { LegalHubPage } from './pages/legal/LegalHubPage';
import { PrivacyPolicyPage } from './pages/legal/PrivacyPolicyPage';
import { TermsOfServicePage } from './pages/legal/TermsOfServicePage';
import { GoogleGuidelinesPage } from './pages/legal/GoogleGuidelinesPage';
import { SecurityGdprPage } from './pages/legal/SecurityGdprPage';

// Business Dashboard Pages
import { DashboardOverview } from './pages/dashboard/DashboardOverview';
import { FeedbackPage } from './pages/dashboard/FeedbackPage';
import { AnalyticsPage } from './pages/dashboard/AnalyticsPage';
import { ReviewPageConfig } from './pages/dashboard/ReviewPageConfig';
import { BusinessProfilePage } from './pages/dashboard/BusinessProfilePage';
import { SettingsPage } from './pages/dashboard/SettingsPage';

// Admin Pages
import { AdminDashboardPage } from './pages/admin/AdminDashboardPage';
import { AdminBusinessesPage } from './pages/admin/AdminBusinessesPage';
import { AdminFeedbackPage } from './pages/admin/AdminFeedbackPage';
import { AdminSettingsPage } from './pages/admin/AdminSettingsPage';

export default function App() {
  return (
    <BrowserRouter>
      <AuthProvider>
        <ToastProvider>
          <Routes>
            {/* Public Routes */}
            <Route path="/" element={<LandingPage />} />
            <Route path="/login" element={<LoginPage />} />
            <Route path="/signup" element={<SignupPage />} />
            <Route path="/forgot-password" element={<ForgotPasswordPage />} />
            <Route path="/r/:slug" element={<PublicReviewPage />} />
            <Route path="/r/:businessSlug" element={<PublicReviewPage />} />
            <Route path="/r" element={<PublicReviewPage />} />

            {/* Security & Legal Pages */}
            <Route path="/legal" element={<LegalHubPage />} />
            <Route path="/security-legal" element={<LegalHubPage />} />
            <Route path="/privacy" element={<PrivacyPolicyPage />} />
            <Route path="/legal/privacy" element={<PrivacyPolicyPage />} />
            <Route path="/terms" element={<TermsOfServicePage />} />
            <Route path="/legal/terms" element={<TermsOfServicePage />} />
            <Route path="/google-guidelines" element={<GoogleGuidelinesPage />} />
            <Route path="/google-policy" element={<GoogleGuidelinesPage />} />
            <Route path="/legal/google-guidelines" element={<GoogleGuidelinesPage />} />
            <Route path="/security" element={<SecurityGdprPage />} />
            <Route path="/gdpr" element={<SecurityGdprPage />} />
            <Route path="/legal/security-gdpr" element={<SecurityGdprPage />} />

            {/* Protected Business Dashboard Routes */}
            <Route
              path="/dashboard"
              element={
                <ProtectedRoute>
                  <DashboardLayout />
                </ProtectedRoute>
              }
            >
              <Route index element={<DashboardOverview />} />
              <Route path="feedback" element={<FeedbackPage />} />
              <Route path="analytics" element={<AnalyticsPage />} />
              <Route path="review-page" element={<ReviewPageConfig />} />
              <Route path="profile" element={<BusinessProfilePage />} />
              <Route path="settings" element={<SettingsPage />} />
            </Route>

            {/* Protected Platform Admin Routes */}
            <Route
              path="/admin"
              element={
                <ProtectedRoute adminOnly>
                  <AdminLayout />
                </ProtectedRoute>
              }
            >
              <Route index element={<AdminDashboardPage />} />
              <Route path="businesses" element={<AdminBusinessesPage />} />
              <Route path="feedback" element={<AdminFeedbackPage />} />
              <Route path="settings" element={<AdminSettingsPage />} />
            </Route>

            {/* Fallback */}
            <Route path="*" element={<Navigate to="/" replace />} />
          </Routes>
        </ToastProvider>
      </AuthProvider>
    </BrowserRouter>
  );
}
