import React from 'react';
import { Card } from './Card';
import { TrendingUp, TrendingDown, Minus } from 'lucide-react';

export interface DashboardCardProps {
  title: string;
  value: string | number;
  change?: string;
  changeType?: 'positive' | 'negative' | 'neutral';
  subtitle?: string;
  icon: React.ReactNode;
  iconBgColor?: string;
  id?: string;
}

export const DashboardCard: React.FC<DashboardCardProps> = ({
  title,
  value,
  change,
  changeType = 'positive',
  subtitle,
  icon,
  iconBgColor = 'bg-indigo-50 text-indigo-600',
  id,
}) => {
  return (
    <Card id={id} className="relative overflow-hidden transition-all duration-200 hover:shadow-md">
      <div className="flex items-start justify-between">
        <div className="flex flex-col">
          <p className="text-xs font-semibold uppercase tracking-wider text-slate-500">{title}</p>
          <div className="mt-2 text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">{value}</div>
        </div>
        <div className={`p-3 rounded-xl shrink-0 ${iconBgColor}`}>
          {icon}
        </div>
      </div>

      {(change || subtitle) && (
        <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-xs">
          {change && (
            <div className="flex items-center gap-1">
              {changeType === 'positive' && <TrendingUp className="w-3.5 h-3.5 text-emerald-600 font-bold" />}
              {changeType === 'negative' && <TrendingDown className="w-3.5 h-3.5 text-rose-600 font-bold" />}
              {changeType === 'neutral' && <Minus className="w-3.5 h-3.5 text-slate-500 font-bold" />}
              <span
                className={`font-semibold ${
                  changeType === 'positive'
                    ? 'text-emerald-700'
                    : changeType === 'negative'
                    ? 'text-rose-700'
                    : 'text-slate-600'
                }`}
              >
                {change}
              </span>
              <span className="text-slate-600 ml-1">vs last month</span>
            </div>
          )}
          {subtitle && <span className="text-slate-600 font-medium">{subtitle}</span>}
        </div>
      )}
    </Card>
  );
};
