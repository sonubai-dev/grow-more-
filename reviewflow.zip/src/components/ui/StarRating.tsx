import React, { useState } from 'react';
import { Star } from 'lucide-react';
import { FeedbackRating } from '../../types';

export interface StarRatingProps {
  rating?: number;
  onChange?: (rating: FeedbackRating) => void;
  interactive?: boolean;
  size?: 'sm' | 'md' | 'lg' | 'xl';
  showLabel?: boolean;
  id?: string;
}

export const StarRating: React.FC<StarRatingProps> = ({
  rating = 0,
  onChange,
  interactive = false,
  size = 'md',
  showLabel = false,
  id = 'star-rating',
}) => {
  const [hoverRating, setHoverRating] = useState<number | null>(null);

  const starSizes = {
    sm: 'w-3.5 h-3.5',
    md: 'w-5 h-5',
    lg: 'w-7 h-7',
    xl: 'w-10 h-10',
  };

  const currentVal = hoverRating !== null ? hoverRating : rating;

  const labels: Record<number, string> = {
    1: 'Poor / Disappointed',
    2: 'Needs Improvement',
    3: 'Average / Neutral',
    4: 'Great Experience',
    5: 'Excellent / Outstanding!',
  };

  return (
    <div id={id} className="flex flex-col items-center gap-2">
      <div className="flex items-center gap-1.5" onMouseLeave={() => interactive && setHoverRating(null)}>
        {([1, 2, 3, 4, 5] as FeedbackRating[]).map((star) => {
          const isFilled = star <= currentVal;
          return (
            <button
              key={star}
              type="button"
              id={`${id}-star-${star}`}
              disabled={!interactive}
              onClick={() => interactive && onChange && onChange(star)}
              onMouseEnter={() => interactive && setHoverRating(star)}
              className={`${
                interactive
                  ? 'cursor-pointer hover:scale-115 active:scale-95 transition-transform p-1'
                  : 'cursor-default p-0'
              } focus:outline-none focus-visible:ring-2 focus-visible:ring-amber-400 rounded-md`}
              aria-label={`${star} star${star > 1 ? 's' : ''}`}
            >
              <Star
                className={`${starSizes[size]} transition-colors duration-150 ${
                  isFilled
                    ? 'fill-amber-400 text-amber-400 drop-shadow-xs'
                    : 'fill-slate-100 text-slate-300'
                }`}
              />
            </button>
          );
        })}
      </div>
      {showLabel && currentVal > 0 && (
        <span className="text-xs font-semibold text-slate-700 transition-opacity animate-in fade-in">
          {labels[Math.round(currentVal)] || ''}
        </span>
      )}
    </div>
  );
};
