import React from 'react';
import { Sparkles, ExternalLink, QrCode, Copy, Check } from 'lucide-react';
import { Button } from '../ui/Button';

interface DashboardHeaderProps {
  businessName: string;
  businessSlug: string;
  reviewLink: string;
  copied: boolean;
  onCopyLink: () => void;
  onOpenQrModal: () => void;
}

export const DashboardHeader: React.FC<DashboardHeaderProps> = ({
  businessName,
  businessSlug,
  reviewLink,
  copied,
  onCopyLink,
  onOpenQrModal,
}) => {
  return (
    <div
      id="dashboard-hero-banner"
      className="bg-linear-to-r from-indigo-900 via-indigo-800 to-slate-900 rounded-3xl p-6 sm:p-8 text-white shadow-xl relative overflow-hidden"
    >
      <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div className="space-y-2 max-w-xl">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-indigo-500/30 text-indigo-200 text-xs font-semibold border border-indigo-400/30">
            <Sparkles className="w-3.5 h-3.5" />
            <span>GrowMore Funnel Active</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-black tracking-tight text-white">
            {businessName}
          </h1>
          <p className="text-xs sm:text-sm text-indigo-100/90 leading-relaxed">
            5-star ratings route instantly to Google Reviews. 1–4 star feedback is privately collected for internal resolution.
          </p>
        </div>

        {/* Quick Action Box: Copy Review Link & Open Review Page */}
        <div className="bg-white/10 backdrop-blur-md p-4 rounded-2xl border border-white/20 flex flex-col sm:flex-row items-center gap-3 shrink-0">
          <div className="flex flex-col text-xs">
            <span className="text-indigo-200 font-semibold">Your Review URL</span>
            <span className="font-mono text-white text-xs font-bold truncate max-w-[180px]">
              /r/{businessSlug}
            </span>
          </div>
          <div className="flex items-center gap-2 w-full sm:w-auto">
            <Button
              id="dash-copy-review-link-btn"
              variant="secondary"
              size="sm"
              onClick={onCopyLink}
              className="bg-white text-slate-900 hover:bg-slate-100 flex-1 sm:flex-initial text-xs font-bold"
              leftIcon={copied ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
            >
              {copied ? 'Review link copied' : 'Copy Review Link'}
            </Button>

            <a
              id="dash-open-review-page-btn"
              href={reviewLink}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-1 px-3 py-2 rounded-xl bg-white/20 hover:bg-white/30 text-white text-xs font-bold transition-colors cursor-pointer"
              title="Open Review Page in New Tab"
            >
              <span>Open Review Page</span>
              <ExternalLink className="w-3.5 h-3.5" />
            </a>

            <Button
              id="dash-open-qr-btn"
              variant="outline"
              size="sm"
              onClick={onOpenQrModal}
              className="border-white/40 text-white hover:bg-white/20 p-2 text-xs font-bold"
              title="View QR Code"
            >
              <QrCode className="w-4 h-4" />
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
};
