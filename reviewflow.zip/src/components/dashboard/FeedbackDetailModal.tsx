import React from 'react';
import { Link } from 'react-router-dom';
import { Star } from 'lucide-react';
import { Modal } from '../ui/Modal';
import { Button } from '../ui/Button';
import { Badge } from '../ui/Badge';
import { FeedbackItem } from '../../types';

interface FeedbackDetailModalProps {
  feedback: FeedbackItem | null;
  businessName: string;
  onClose: () => void;
}

export const FeedbackDetailModal: React.FC<FeedbackDetailModalProps> = ({
  feedback,
  businessName,
  onClose,
}) => {
  return (
    <Modal
      isOpen={!!feedback}
      onClose={onClose}
      title="Feedback Details"
      description={`Customer submission for ${businessName}`}
    >
      {feedback && (
        <div className="space-y-5">
          <div className="flex items-center justify-between p-4 rounded-xl bg-slate-50 border border-slate-200">
            <div>
              <span className="text-xs text-slate-600 uppercase font-bold tracking-wider">
                Rating Given
              </span>
              <div className="flex items-center gap-1.5 mt-1">
                <span className="text-2xl font-extrabold text-slate-900">{feedback.rating} / 5</span>
                <Star className="w-5 h-5 fill-amber-400 text-amber-400" />
              </div>
            </div>
            <div className="text-right">
              <span className="text-xs text-slate-600 uppercase font-bold tracking-wider">
                Routing Action
              </span>
              <div className="mt-1">
                {feedback.rating === 5 ? (
                  <Badge variant="success" size="md">
                    5-Star Google Redirect
                  </Badge>
                ) : (
                  <Badge variant="warning" size="md">
                    Private Feedback Ticket
                  </Badge>
                )}
              </div>
            </div>
          </div>

          <div>
            <label className="text-xs font-bold uppercase tracking-wider text-slate-500">
              Customer Comment
            </label>
            <div className="mt-1.5 p-4 rounded-xl bg-white border border-slate-200 text-sm text-slate-800 leading-relaxed italic">
              {feedback.comment ? `"${feedback.comment}"` : 'No written comment submitted'}
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4 text-xs">
            <div className="p-3 rounded-lg bg-slate-50 border border-slate-200">
              <span className="text-slate-600 block">Customer Name</span>
              <span className="font-semibold text-slate-900 text-sm">
                {feedback.customerName || 'Anonymous'}
              </span>
            </div>
            <div className="p-3 rounded-lg bg-slate-50 border border-slate-200">
              <span className="text-slate-600 block">Contact Info</span>
              <span className="font-semibold text-slate-900 text-sm">
                {feedback.customerEmail || feedback.customerPhone || 'None provided'}
              </span>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4 text-xs">
            <div className="p-3 rounded-lg bg-slate-50 border border-slate-200">
              <span className="text-slate-600 block">Source</span>
              <span className="font-semibold text-slate-900 text-sm">
                {feedback.source || 'public_review_page'}
              </span>
            </div>
            <div className="p-3 rounded-lg bg-slate-50 border border-slate-200">
              <span className="text-slate-600 block">Date Submitted</span>
              <span className="font-semibold text-slate-900 text-sm">
                {new Date(feedback.createdAt).toLocaleString()}
              </span>
            </div>
          </div>

          <div className="pt-2 flex justify-end gap-2">
            <Button variant="outline" size="sm" onClick={onClose}>
              Close
            </Button>
            <Link to="/dashboard/feedback">
              <Button variant="primary" size="sm">
                Open Feedback Manager
              </Button>
            </Link>
          </div>
        </div>
      )}
    </Modal>
  );
};
