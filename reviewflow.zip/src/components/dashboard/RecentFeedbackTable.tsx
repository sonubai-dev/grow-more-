import React from 'react';
import { Link } from 'react-router-dom';
import { Star, ArrowRight, Eye } from 'lucide-react';
import { Card } from '../ui/Card';
import { Button } from '../ui/Button';
import { Badge } from '../ui/Badge';
import { FeedbackItem } from '../../types';

interface RecentFeedbackTableProps {
  feedback: FeedbackItem[];
  onSelectFeedback: (item: FeedbackItem) => void;
}

export const RecentFeedbackTable: React.FC<RecentFeedbackTableProps> = ({
  feedback,
  onSelectFeedback,
}) => {
  return (
    <Card className="p-6" id="recent-feedback-feed">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
        <div>
          <h3 className="text-base font-bold text-slate-900">Recent Customer Submissions</h3>
          <p className="text-xs text-slate-500 mt-0.5">
            Latest reviews received through your public link and QR stands
          </p>
        </div>
        <Link to="/dashboard/feedback">
          <Button variant="outline" size="sm" rightIcon={<ArrowRight className="w-3.5 h-3.5" />}>
            Open Feedback Manager
          </Button>
        </Link>
      </div>

      <div className="overflow-x-auto">
        <table className="w-full text-left text-sm text-slate-600">
          <thead className="bg-slate-50 text-xs uppercase font-bold text-slate-500 border-y border-slate-200">
            <tr>
              <th className="py-3 px-4">Customer</th>
              <th className="py-3 px-4">Rating</th>
              <th className="py-3 px-4">Comment</th>
              <th className="py-3 px-4">Routing / Status</th>
              <th className="py-3 px-4">Date</th>
              <th className="py-3 px-4 text-right">Action</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {feedback.length === 0 ? (
              <tr>
                <td colSpan={6} className="py-8 text-center text-xs text-slate-400">
                  No customer feedback in selected date period.
                </td>
              </tr>
            ) : (
              feedback.slice(0, 6).map((item) => (
                <tr key={item.id} className="hover:bg-slate-50/80 transition-colors">
                  <td className="py-3.5 px-4">
                    <div className="font-semibold text-slate-900">
                      {item.customerName || 'Anonymous Customer'}
                    </div>
                    <div className="text-xs text-slate-500">
                      {item.customerEmail || item.customerPhone || 'No contact provided'}
                    </div>
                  </td>
                  <td className="py-3.5 px-4">
                    <div className="flex items-center gap-1">
                      <span className="font-bold text-slate-900">{item.rating}</span>
                      <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
                    </div>
                  </td>
                  <td className="py-3.5 px-4 max-w-xs truncate text-xs text-slate-700">
                    {item.comment ? (
                      `"${item.comment}"`
                    ) : (
                      <span className="text-slate-400 italic">No comment left</span>
                    )}
                  </td>
                  <td className="py-3.5 px-4">
                    {item.rating === 5 ? (
                      <Badge variant="success" size="sm">
                        {item.googleRedirected ? 'Google Review Clicked' : '5-Star Google Eligible'}
                      </Badge>
                    ) : (
                      <Badge variant="warning" size="sm">
                        Private Feedback Ticket
                      </Badge>
                    )}
                  </td>
                  <td className="py-3.5 px-4 text-xs text-slate-600">
                    {new Date(item.createdAt).toLocaleDateString(undefined, {
                      month: 'short',
                      day: 'numeric',
                    })}
                  </td>
                  <td className="py-3.5 px-4 text-right">
                    <button
                      id={`view-feedback-${item.id}`}
                      onClick={() => onSelectFeedback(item)}
                      className="p-1.5 text-slate-400 hover:text-indigo-600 hover:bg-indigo-50 rounded-lg transition-colors inline-flex items-center gap-1 text-xs font-semibold cursor-pointer"
                    >
                      <Eye className="w-4 h-4" />
                      <span>Details</span>
                    </button>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </Card>
  );
};
