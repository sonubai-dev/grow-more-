import React, { useState, useEffect } from 'react';
import {
  MessageSquare,
  Search,
  Filter,
  Star,
  Sparkles,
  ShieldAlert,
  CheckCircle2,
  Clock,
  ExternalLink,
  ChevronLeft,
  ChevronRight,
  Eye,
  Send,
  Loader2,
  Phone,
  Mail,
  User,
  Calendar,
  AlertTriangle,
} from 'lucide-react';
import { Card } from '../../components/ui/Card';
import { Button } from '../../components/ui/Button';
import { Input } from '../../components/ui/Input';
import { Badge } from '../../components/ui/Badge';
import { Modal } from '../../components/ui/Modal';
import { EmptyState } from '../../components/ui/EmptyState';
import { FeedbackItem, FeedbackRating, FeedbackStatus } from '../../types';
import { useAuth } from '../../context/AuthContext';
import { useToast } from '../../context/ToastContext';
import {
  getFeedbackByBusiness,
  updateFeedbackItem,
} from '../../services/feedbackService';

export const FeedbackPage: React.FC = () => {
  const { currentBusiness } = useAuth();
  const { addToast } = useToast();

  const businessId = currentBusiness?.id || 'apex-dental';
  const ownerId = currentBusiness?.ownerId || '';
  const businessName = currentBusiness?.businessName || currentBusiness?.name || 'Your Business';

  const [loading, setLoading] = useState(true);
  const [feedbackList, setFeedbackList] = useState<FeedbackItem[]>([]);
  const [ratingFilter, setRatingFilter] = useState<'all' | 5 | 4 | 3 | 2 | 1>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 8;

  const [selectedItem, setSelectedItem] = useState<FeedbackItem | null>(null);
  const [internalNoteInput, setInternalNoteInput] = useState('');
  const [updatingStatus, setUpdatingStatus] = useState(false);

  // Load real Firestore feedback
  useEffect(() => {
    let isMounted = true;

    async function loadData() {
      setLoading(true);
      try {
        const data = await getFeedbackByBusiness(businessId, ownerId);
        if (isMounted) {
          setFeedbackList(data);
        }
      } catch (err) {
        console.warn('Error loading feedback list:', err);
      } finally {
        if (isMounted) setLoading(false);
      }
    }

    loadData();

    return () => {
      isMounted = false;
    };
  }, [businessId, ownerId]);

  // Reset to page 1 whenever filters change
  useEffect(() => {
    setCurrentPage(1);
  }, [ratingFilter, searchQuery]);

  // Filter items
  const filteredItems = feedbackList.filter((item) => {
    // Rating Filter: All, 5 star, 4 star, 3 star, 2 star, 1 star
    if (ratingFilter !== 'all' && item.rating !== ratingFilter) {
      return false;
    }

    // Search query
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const matchName = item.customerName?.toLowerCase().includes(q);
      const matchComment = item.comment?.toLowerCase().includes(q);
      const matchEmail = item.customerEmail?.toLowerCase().includes(q);
      const matchPhone = item.customerPhone?.toLowerCase().includes(q);
      if (!matchName && !matchComment && !matchEmail && !matchPhone) return false;
    }

    return true;
  });

  // Pagination calculation
  const totalPages = Math.max(1, Math.ceil(filteredItems.length / itemsPerPage));
  const paginatedItems = filteredItems.slice(
    (currentPage - 1) * itemsPerPage,
    currentPage * itemsPerPage
  );

  const handleUpdateStatus = async (id: string, newStatus: FeedbackStatus) => {
    setUpdatingStatus(true);
    try {
      await updateFeedbackItem(id, { status: newStatus });
      setFeedbackList((prev) =>
        prev.map((item) => (item.id === id ? { ...item, status: newStatus } : item))
      );
      if (selectedItem && selectedItem.id === id) {
        setSelectedItem((prev) => (prev ? { ...prev, status: newStatus } : null));
      }
      addToast('success', `Feedback status updated to ${newStatus}.`, 'Status Updated');
    } catch (err) {
      console.warn('Error updating status:', err);
      addToast('error', 'Could not update status.', 'Update Failed');
    } finally {
      setUpdatingStatus(false);
    }
  };

  const handleAddNote = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedItem || !internalNoteInput.trim()) return;

    const noteText = internalNoteInput.trim();
    try {
      await updateFeedbackItem(selectedItem.id, { internalNotes: noteText });
      setFeedbackList((prev) =>
        prev.map((item) =>
          item.id === selectedItem.id ? { ...item, internalNotes: noteText } : item
        )
      );
      setSelectedItem((prev) =>
        prev ? { ...prev, internalNotes: noteText } : null
      );
      setInternalNoteInput('');
      addToast('success', 'Internal team note saved.', 'Note Saved');
    } catch (err) {
      console.warn('Error saving note:', err);
    }
  };

  // Counts for each star filter
  const count5 = feedbackList.filter((f) => f.rating === 5).length;
  const count4 = feedbackList.filter((f) => f.rating === 4).length;
  const count3 = feedbackList.filter((f) => f.rating === 3).length;
  const count2 = feedbackList.filter((f) => f.rating === 2).length;
  const count1 = feedbackList.filter((f) => f.rating === 1).length;

  return (
    <div id="feedback-page-root" className="space-y-6 max-w-7xl mx-auto">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-extrabold text-slate-900 tracking-tight">
            Customer Feedback & Review Submissions
          </h1>
          <p className="text-sm text-slate-500 mt-1">
            Browse, filter, and respond to incoming customer ratings for {businessName}.
          </p>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <Card className="p-4 sm:p-5">
        <div className="flex flex-col lg:flex-row items-center justify-between gap-4">
          {/* Star Rating Filters: All, 5 star, 4 star, 3 star, 2 star, 1 star */}
          <div className="flex items-center gap-1.5 overflow-x-auto w-full lg:w-auto pb-1 lg:pb-0">
            <button
              id="filter-all"
              onClick={() => setRatingFilter('all')}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all shrink-0 cursor-pointer ${
                ratingFilter === 'all'
                  ? 'bg-indigo-600 text-white shadow-xs'
                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
            >
              All ({feedbackList.length})
            </button>

            <button
              id="filter-5-star"
              onClick={() => setRatingFilter(5)}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1 shrink-0 cursor-pointer ${
                ratingFilter === 5
                  ? 'bg-emerald-600 text-white shadow-xs'
                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
            >
              <Star className="w-3 h-3 fill-current" /> 5 Star ({count5})
            </button>

            <button
              id="filter-4-star"
              onClick={() => setRatingFilter(4)}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1 shrink-0 cursor-pointer ${
                ratingFilter === 4
                  ? 'bg-teal-600 text-white shadow-xs'
                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
            >
              <Star className="w-3 h-3 fill-current" /> 4 Star ({count4})
            </button>

            <button
              id="filter-3-star"
              onClick={() => setRatingFilter(3)}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1 shrink-0 cursor-pointer ${
                ratingFilter === 3
                  ? 'bg-amber-600 text-white shadow-xs'
                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
            >
              <Star className="w-3 h-3 fill-current" /> 3 Star ({count3})
            </button>

            <button
              id="filter-2-star"
              onClick={() => setRatingFilter(2)}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1 shrink-0 cursor-pointer ${
                ratingFilter === 2
                  ? 'bg-orange-600 text-white shadow-xs'
                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
            >
              <Star className="w-3 h-3 fill-current" /> 2 Star ({count2})
            </button>

            <button
              id="filter-1-star"
              onClick={() => setRatingFilter(1)}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1 shrink-0 cursor-pointer ${
                ratingFilter === 1
                  ? 'bg-rose-600 text-white shadow-xs'
                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
            >
              <Star className="w-3 h-3 fill-current" /> 1 Star ({count1})
            </button>
          </div>

          {/* Search Box */}
          <div className="w-full lg:w-72">
            <Input
              id="search-feedback-input"
              placeholder="Search comments, customer, email..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              leftIcon={<Search className="w-4 h-4" />}
            />
          </div>
        </div>
      </Card>

      {/* Main Feedback Table Card */}
      <Card className="overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-sm text-slate-600">
            <thead className="bg-slate-50 text-xs uppercase font-bold text-slate-500 border-b border-slate-200">
              <tr>
                <th className="py-3.5 px-4 sm:px-6">Rating</th>
                <th className="py-3.5 px-4 sm:px-6">Comment</th>
                <th className="py-3.5 px-4 sm:px-6">Customer</th>
                <th className="py-3.5 px-4 sm:px-6">Date</th>
                <th className="py-3.5 px-4 sm:px-6">Status</th>
                <th className="py-3.5 px-4 sm:px-6 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {loading ? (
                <tr>
                  <td colSpan={6} className="py-12 text-center text-slate-500">
                    <Loader2 className="w-6 h-6 animate-spin mx-auto text-indigo-600 mb-2" />
                    <span>Loading feedback from Firestore...</span>
                  </td>
                </tr>
              ) : paginatedItems.length === 0 ? (
                <tr>
                  <td colSpan={6} className="py-12 text-center">
                    <EmptyState
                      title="No feedback matching your filters"
                      description={
                        searchQuery
                          ? `No results found for "${searchQuery}". Try adjusting your search query.`
                          : 'No feedback submissions found in this category.'
                      }
                      icon={<MessageSquare className="w-10 h-10 text-slate-400" />}
                    />
                  </td>
                </tr>
              ) : (
                paginatedItems.map((item) => (
                  <tr key={item.id} className="hover:bg-slate-50/80 transition-colors">
                    {/* Rating Column */}
                    <td className="py-4 px-4 sm:px-6 whitespace-nowrap">
                      <div className="flex items-center gap-1.5">
                        <span
                          className={`font-black text-sm px-2 py-0.5 rounded-md ${
                            item.rating === 5
                              ? 'bg-emerald-50 text-emerald-700'
                              : item.rating === 4
                              ? 'bg-teal-50 text-teal-700'
                              : item.rating === 3
                              ? 'bg-amber-50 text-amber-700'
                              : 'bg-rose-50 text-rose-700'
                          }`}
                        >
                          {item.rating} ★
                        </span>
                        <div className="flex text-amber-400">
                          {Array.from({ length: 5 }).map((_, i) => (
                            <Star
                              key={i}
                              className={`w-3.5 h-3.5 ${
                                i < item.rating
                                  ? 'fill-amber-400 text-amber-400'
                                  : 'text-slate-200'
                              }`}
                            />
                          ))}
                        </div>
                      </div>
                    </td>

                    {/* Comment Column */}
                    <td className="py-4 px-4 sm:px-6 max-w-xs md:max-w-md">
                      <p className="text-xs sm:text-sm text-slate-800 line-clamp-2 italic leading-relaxed">
                        {item.comment ? `"${item.comment}"` : <span className="text-slate-400 font-normal not-italic">No comment provided</span>}
                      </p>
                      {item.internalNotes && (
                        <div className="mt-1 text-[11px] text-indigo-700 bg-indigo-50/80 px-2 py-0.5 rounded inline-block font-semibold">
                          Note: {item.internalNotes}
                        </div>
                      )}
                    </td>

                    {/* Customer Column */}
                    <td className="py-4 px-4 sm:px-6">
                      <div className="font-bold text-slate-900 text-xs sm:text-sm">
                        {item.customerName || 'Anonymous Customer'}
                      </div>
                      <div className="text-xs text-slate-500 truncate max-w-[160px]">
                        {item.customerEmail || item.customerPhone || 'No contact info'}
                      </div>
                    </td>

                    {/* Date Column */}
                    <td className="py-4 px-4 sm:px-6 whitespace-nowrap text-xs text-slate-500">
                      <div className="font-semibold text-slate-700">
                        {new Date(item.createdAt).toLocaleDateString(undefined, {
                          month: 'short',
                          day: 'numeric',
                          year: 'numeric',
                        })}
                      </div>
                      <div className="text-[11px] text-slate-400">
                        {new Date(item.createdAt).toLocaleTimeString([], {
                          hour: '2-digit',
                          minute: '2-digit',
                        })}
                      </div>
                    </td>

                    {/* Status Column */}
                    <td className="py-4 px-4 sm:px-6 whitespace-nowrap">
                      {item.rating === 5 ? (
                        <Badge variant="success" size="sm">
                          {item.googleRedirected ? 'Google Review Clicked' : '5-Star Google Eligible'}
                        </Badge>
                      ) : item.status === 'resolved' ? (
                        <Badge variant="success" size="sm">
                          Resolved
                        </Badge>
                      ) : item.status === 'reviewed' ? (
                        <Badge variant="info" size="sm">
                          Reviewed
                        </Badge>
                      ) : (
                        <Badge variant="warning" size="sm">
                          New Private Ticket
                        </Badge>
                      )}
                    </td>

                    {/* Actions Column */}
                    <td className="py-4 px-4 sm:px-6 text-right whitespace-nowrap">
                      <Button
                        id={`view-btn-${item.id}`}
                        variant="outline"
                        size="sm"
                        onClick={() => {
                          setSelectedItem(item);
                          setInternalNoteInput(item.internalNotes || '');
                        }}
                        leftIcon={<Eye className="w-3.5 h-3.5" />}
                      >
                        Details
                      </Button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>

        {/* Pagination Controls */}
        <div className="p-4 bg-slate-50 border-t border-slate-200 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-slate-600">
          <div>
            Showing{' '}
            <span className="font-bold text-slate-900">
              {filteredItems.length === 0
                ? 0
                : (currentPage - 1) * itemsPerPage + 1}
            </span>{' '}
            to{' '}
            <span className="font-bold text-slate-900">
              {Math.min(currentPage * itemsPerPage, filteredItems.length)}
            </span>{' '}
            of <span className="font-bold text-slate-900">{filteredItems.length}</span> entries
          </div>

          <div className="flex items-center gap-1.5">
            <Button
              variant="outline"
              size="sm"
              disabled={currentPage <= 1}
              onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
              leftIcon={<ChevronLeft className="w-3.5 h-3.5" />}
            >
              Previous
            </Button>

            <div className="px-2 font-bold text-slate-700">
              Page {currentPage} of {totalPages}
            </div>

            <Button
              variant="outline"
              size="sm"
              disabled={currentPage >= totalPages}
              onClick={() => setCurrentPage((p) => Math.min(totalPages, p + 1))}
              rightIcon={<ChevronRight className="w-3.5 h-3.5" />}
            >
              Next
            </Button>
          </div>
        </div>
      </Card>

      {/* Details & Resolution Modal */}
      <Modal
        isOpen={!!selectedItem}
        onClose={() => setSelectedItem(null)}
        title="Feedback & Customer Details"
        description="Private feedback ticket submitted via public review page"
        maxWidth="lg"
      >
        {selectedItem && (
          <div className="space-y-6">
            {/* Top Score summary */}
            <div className="flex items-center justify-between p-4 rounded-2xl bg-slate-50 border border-slate-200">
              <div className="flex items-center gap-3">
                <div
                  className={`w-12 h-12 rounded-xl flex items-center justify-center font-black text-xl text-white shadow-xs ${
                    selectedItem.rating === 5
                      ? 'bg-emerald-600'
                      : selectedItem.rating === 4
                      ? 'bg-teal-600'
                      : selectedItem.rating === 3
                      ? 'bg-amber-500'
                      : 'bg-rose-600'
                  }`}
                >
                  {selectedItem.rating}★
                </div>
                <div>
                  <h4 className="font-bold text-slate-900 text-base">
                    {selectedItem.rating} out of 5 Stars
                  </h4>
                  <p className="text-xs text-slate-500">
                    Source: {selectedItem.source || 'public_review_page'}
                  </p>
                </div>
              </div>

              <div>
                {selectedItem.rating === 5 ? (
                  <Badge variant="success" size="md">
                    {selectedItem.googleRedirected ? 'Google Review Clicked' : '5-Star Direct'}
                  </Badge>
                ) : (
                  <Badge variant={selectedItem.status === 'resolved' ? 'success' : 'warning'} size="md">
                    {selectedItem.status?.toUpperCase() || 'NEW TICKET'}
                  </Badge>
                )}
              </div>
            </div>

            {/* Comment */}
            <div>
              <label className="text-xs font-bold uppercase tracking-wider text-slate-500 block mb-1">
                Customer Message
              </label>
              <div className="p-4 rounded-2xl bg-white border border-slate-200 text-sm text-slate-800 leading-relaxed italic">
                {selectedItem.comment ? `"${selectedItem.comment}"` : 'No written feedback was provided.'}
              </div>
            </div>

            {/* Customer Details */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
              <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 space-y-1">
                <span className="text-slate-500 flex items-center gap-1 font-semibold">
                  <User className="w-3.5 h-3.5" /> Customer Name
                </span>
                <span className="font-bold text-slate-900 block text-sm">
                  {selectedItem.customerName || 'Anonymous'}
                </span>
              </div>

              <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 space-y-1">
                <span className="text-slate-500 flex items-center gap-1 font-semibold">
                  <Mail className="w-3.5 h-3.5" /> Email
                </span>
                <span className="font-bold text-slate-900 block text-sm truncate">
                  {selectedItem.customerEmail || 'None provided'}
                </span>
              </div>

              <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 space-y-1">
                <span className="text-slate-500 flex items-center gap-1 font-semibold">
                  <Phone className="w-3.5 h-3.5" /> Phone
                </span>
                <span className="font-bold text-slate-900 block text-sm">
                  {selectedItem.customerPhone || 'None provided'}
                </span>
              </div>
            </div>

            {/* Internal Resolution Note */}
            <form onSubmit={handleAddNote} className="space-y-3 pt-2">
              <label htmlFor="internal-note-input" className="text-xs font-bold uppercase tracking-wider text-slate-700 block">
                Internal Team Notes
              </label>
              <div className="flex gap-2">
                <Input
                  id="internal-note-input"
                  placeholder="e.g. Called customer, offered refund, issue resolved..."
                  value={internalNoteInput}
                  onChange={(e) => setInternalNoteInput(e.target.value)}
                  className="flex-1"
                />
                <Button type="submit" variant="primary" size="md" leftIcon={<Send className="w-4 h-4" />}>
                  Save Note
                </Button>
              </div>
            </form>

            {/* Status Switcher & Close */}
            <div className="pt-4 border-t border-slate-100 flex flex-col sm:flex-row items-center justify-between gap-3">
              <div className="flex items-center gap-2">
                <span className="text-xs font-semibold text-slate-500">Update Status:</span>
                <Button
                  variant="outline"
                  size="sm"
                  disabled={updatingStatus}
                  onClick={() => handleUpdateStatus(selectedItem.id, 'reviewed')}
                  className={selectedItem.status === 'reviewed' ? 'border-indigo-600 bg-indigo-50 text-indigo-700' : ''}
                >
                  Mark Reviewed
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  disabled={updatingStatus}
                  onClick={() => handleUpdateStatus(selectedItem.id, 'resolved')}
                  className={selectedItem.status === 'resolved' ? 'border-emerald-600 bg-emerald-50 text-emerald-700' : ''}
                >
                  Mark Resolved
                </Button>
              </div>

              <Button variant="secondary" size="sm" onClick={() => setSelectedItem(null)}>
                Close
              </Button>
            </div>
          </div>
        )}
      </Modal>
    </div>
  );
};
