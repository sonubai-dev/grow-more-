import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { StarRating } from '../../components/ui/StarRating';
import { Button } from '../../components/ui/Button';
import { Card } from '../../components/ui/Card';
import { Input } from '../../components/ui/Input';
import { Business, FeedbackRating } from '../../types';
import { MOCK_BUSINESSES } from '../../data/mockData';
import { getBusinessBySlug } from '../../services/businessService';
import {
  submitFeedback,
  recordGoogleReviewClick,
} from '../../services/feedbackService';
import {
  CheckCircle2,
  Star,
  ExternalLink,
  Heart,
  Sparkles,
  ShieldCheck,
  MapPin,
  AlertTriangle,
  Home,
  Loader2,
  ArrowRight,
  Send,
  MessageSquare,
} from 'lucide-react';

export const PublicReviewPage: React.FC = () => {
  const params = useParams<{ slug?: string; businessSlug?: string }>();
  const rawSlug = params.slug || params.businessSlug || '';

  const [business, setBusiness] = useState<Business | null>(null);
  const [loading, setLoading] = useState(true);
  const [notFound, setNotFound] = useState(false);

  // Rating State: 0 (unselected), 1-5
  const [rating, setRating] = useState<FeedbackRating | 0>(0);

  // 1-4 Star Feedback Form Fields
  const [comment, setComment] = useState('');
  const [customerName, setCustomerName] = useState('');
  const [customerEmail, setCustomerEmail] = useState('');
  const [customerPhone, setCustomerPhone] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [submitted1to4, setSubmitted1to4] = useState(false);

  // 5-Star State & Google Redirect
  const [redirectingGoogle, setRedirectingGoogle] = useState(false);
  const [googleRedirectSuccess, setGoogleRedirectSuccess] = useState(false);

  useEffect(() => {
    let isMounted = true;

    async function loadBusinessData() {
      setLoading(true);
      setNotFound(false);

      if (!rawSlug) {
        const defaultBiz = MOCK_BUSINESSES[0];
        if (isMounted) {
          setBusiness(defaultBiz);
          setLoading(false);
        }
        return;
      }

      try {
        const firestoreBiz = await getBusinessBySlug(rawSlug);
        if (firestoreBiz) {
          if (isMounted) {
            setBusiness(firestoreBiz);
            setLoading(false);
          }
          return;
        }

        const matchedMock = MOCK_BUSINESSES.find(
          (b) => b.slug.toLowerCase() === rawSlug.toLowerCase()
        );

        if (matchedMock) {
          if (isMounted) {
            setBusiness(matchedMock);
            setLoading(false);
          }
          return;
        }

        if (isMounted) {
          setBusiness(null);
          setNotFound(true);
          setLoading(false);
        }
      } catch (err) {
        console.warn('Error loading public business:', err);
        if (isMounted) {
          setNotFound(true);
          setLoading(false);
        }
      }
    }

    loadBusinessData();

    return () => {
      isMounted = false;
    };
  }, [rawSlug]);

  const businessDisplayName = business?.businessName || business?.name || 'Verified Business';
  const headerAccentColor = business?.headerColor || '#4f46e5';

  // Handle 1-4 Star Feedback Submission
  const handle1to4Submit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!business || rating === 0 || rating > 4) return;

    setSubmitting(true);
    try {
      await submitFeedback({
        businessId: business.id,
        ownerId: business.ownerId,
        rating: rating as FeedbackRating,
        comment: comment.trim(),
        customerName: customerName.trim(),
        customerEmail: customerEmail.trim(),
        customerPhone: customerPhone.trim(),
        source: 'public_review_page',
        googleRedirected: false,
      });

      setSubmitted1to4(true);
    } catch (err) {
      console.error('Failed to submit feedback:', err);
      // Still show success to customer to maintain a positive user experience
      setSubmitted1to4(true);
    } finally {
      setSubmitting(false);
    }
  };

  // Handle 5-Star "Leave a Google Review" button click
  const handleGoogleReviewClick = async () => {
    if (!business) return;

    setRedirectingGoogle(true);
    const googleUrl =
      business.googleReviewUrl?.trim() ||
      `https://search.google.com/local/writereview?placeid=${business.googlePlaceId || 'ChIJpyiwa4Zw44kRBQSGWKv4wgA'}`;

    try {
      // 1. Submit 5-star feedback record
      const fbRecord = await submitFeedback({
        businessId: business.id,
        ownerId: business.ownerId,
        rating: 5,
        comment: 'Customer initiated Google review',
        customerName: '',
        customerEmail: '',
        customerPhone: '',
        source: 'public_review_page',
        googleRedirected: true,
      });

      // 2. Record click event in reviewClicks collection
      await recordGoogleReviewClick(business.id, fbRecord?.id || null, business.ownerId);

      setGoogleRedirectSuccess(true);

      // 3. Open Google review page
      const win = window.open(googleUrl, '_blank', 'noopener,noreferrer');
      if (!win) {
        window.location.href = googleUrl;
      }
    } catch (err) {
      console.warn('Error during click tracking:', err);
      window.open(googleUrl, '_blank', 'noopener,noreferrer');
    } finally {
      setRedirectingGoogle(false);
    }
  };

  // Loading View
  if (loading) {
    return (
      <div id="public-review-loading" className="min-h-screen bg-slate-100 flex items-center justify-center p-4">
        <div className="text-center space-y-3 bg-white p-8 rounded-3xl border border-slate-200 shadow-md max-w-sm w-full">
          <Loader2 className="w-8 h-8 text-indigo-600 animate-spin mx-auto" />
          <h2 className="text-base font-bold text-slate-800">Connecting to Business Portal...</h2>
          <p className="text-xs text-slate-500">Loading verified feedback channel</p>
        </div>
      </div>
    );
  }

  // 404 Not Found View
  if (notFound || !business) {
    return (
      <div id="business-not-found-page" className="min-h-screen bg-slate-100 flex flex-col justify-between py-12 px-4 sm:px-6">
        <div className="w-full max-w-md mx-auto my-auto text-center">
          <Card className="p-8 sm:p-10 bg-white border border-slate-200/90 shadow-xl rounded-3xl space-y-6">
            <div className="w-20 h-20 rounded-3xl bg-amber-50 border-2 border-amber-200 text-amber-600 flex items-center justify-center mx-auto shadow-xs">
              <AlertTriangle className="w-10 h-10" />
            </div>

            <div className="space-y-2">
              <span className="inline-block px-3 py-1 rounded-full bg-slate-100 text-slate-600 text-xs font-mono font-bold">
                404 • Not Found
              </span>
              <h1 className="text-2xl font-extrabold text-slate-900 tracking-tight">
                Business Portal Not Found
              </h1>
              <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
                The review link{' '}
                <span className="font-mono text-indigo-600 font-bold bg-indigo-50 px-1.5 py-0.5 rounded">
                  /r/{rawSlug}
                </span>{' '}
                does not correspond to an active business or may have been renamed.
              </p>
            </div>

            <div className="pt-2 flex flex-col gap-3">
              <Link to="/">
                <Button variant="primary" className="w-full justify-center" size="md" leftIcon={<Home className="w-4 h-4" />}>
                  Return to GrowMore Home
                </Button>
              </Link>
            </div>
          </Card>
        </div>

        <div className="text-center text-xs text-slate-400">
          Powered by <Link to="/" className="text-indigo-600 hover:underline font-semibold">GrowMore</Link>
        </div>
      </div>
    );
  }

  // Suspended Business View
  if (business.status === 'suspended' || business.isActive === false) {
    return (
      <div id="business-suspended-page" className="min-h-screen bg-slate-100 flex flex-col justify-between py-12 px-4 sm:px-6">
        <div className="w-full max-w-md mx-auto my-auto text-center">
          <Card className="p-8 sm:p-10 bg-white border border-slate-200/90 shadow-xl rounded-3xl space-y-6">
            <div className="w-20 h-20 rounded-3xl bg-red-50 border-2 border-red-200 text-red-600 flex items-center justify-center mx-auto shadow-xs">
              <AlertTriangle className="w-10 h-10" />
            </div>

            <div className="space-y-2">
              <span className="inline-block px-3 py-1 rounded-full bg-red-100 text-red-700 text-xs font-mono font-bold">
                Account Suspended
              </span>
              <h1 className="text-2xl font-extrabold text-slate-900 tracking-tight">
                Feedback Channel Suspended
              </h1>
              <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
                Feedback collection for <strong>{businessDisplayName}</strong> is currently paused or inactive by platform administration.
              </p>
            </div>

            <div className="pt-2 flex flex-col gap-3">
              <Link to="/">
                <Button variant="outline" className="w-full justify-center" size="md" leftIcon={<Home className="w-4 h-4" />}>
                  Return to Home
                </Button>
              </Link>
            </div>
          </Card>
        </div>

        <div className="text-center text-xs text-slate-400">
          Powered by <Link to="/" className="text-indigo-600 hover:underline font-semibold">GrowMore</Link>
        </div>
      </div>
    );
  }

  return (
    <div
      id="public-review-page-root"
      className="min-h-screen bg-slate-100 flex flex-col justify-between py-8 px-4 sm:px-6 lg:px-8 selection:bg-indigo-500 selection:text-white"
    >
      {/* Top Header */}
      <div className="w-full max-w-lg mx-auto flex items-center justify-between text-xs text-slate-500 mb-4">
        <Link to="/" className="inline-flex items-center gap-1.5 font-bold text-slate-700 hover:text-indigo-600">
          <Sparkles className="w-4 h-4 text-indigo-600" />
          <span>GrowMore Verified</span>
        </Link>
        <span className="inline-flex items-center gap-1 text-slate-500">
          <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" /> Verified Customer Portal
        </span>
      </div>

      {/* Main Container */}
      <div className="w-full max-w-lg mx-auto my-auto space-y-4">
        <Card className="p-6 sm:p-8 bg-white border border-slate-200/90 shadow-xl rounded-3xl overflow-hidden relative">
          {/* Top Brand Accent Strip */}
          <div
            className="absolute top-0 left-0 right-0 h-2"
            style={{ backgroundColor: headerAccentColor }}
          />

          {/* Business Branding */}
          <div className="text-center space-y-3 pt-2">
            {business.logoUrl ? (
              <div className="w-20 h-20 rounded-2xl border-2 border-indigo-100 bg-white shadow-xs mx-auto overflow-hidden flex items-center justify-center p-1">
                <img
                  src={business.logoUrl}
                  alt={businessDisplayName}
                  className="w-full h-full object-contain rounded-xl"
                />
              </div>
            ) : (
              <div className="w-16 h-16 rounded-2xl bg-indigo-50 border-2 border-indigo-100 flex items-center justify-center text-indigo-700 font-extrabold text-xl shadow-xs mx-auto">
                {businessDisplayName
                  .split(' ')
                  .map((n) => n[0])
                  .slice(0, 2)
                  .join('')}
              </div>
            )}

            <div>
              <h1 className="text-xl sm:text-2xl font-extrabold text-slate-900 tracking-tight">
                {businessDisplayName}
              </h1>
              <p className="text-xs text-slate-500 font-medium mt-0.5">
                {business.category}
              </p>
              {business.address && (
                <p className="text-[11px] text-slate-400 flex items-center justify-center gap-1 mt-1 truncate max-w-xs mx-auto">
                  <MapPin className="w-3 h-3 text-slate-400 shrink-0" />
                  <span>{business.address}</span>
                </p>
              )}
            </div>
          </div>

          <div className="mt-6">
            {/* ============================================================== */}
            {/* SUBMITTED STATE: 1-4 Stars */}
            {/* ============================================================== */}
            {submitted1to4 ? (
              <div className="text-center py-6 space-y-4 animate-in fade-in duration-300">
                <div className="w-16 h-16 rounded-2xl bg-emerald-50 border-2 border-emerald-200 text-emerald-600 flex items-center justify-center mx-auto shadow-xs">
                  <CheckCircle2 className="w-8 h-8" />
                </div>
                <div className="space-y-1.5">
                  <h3 className="text-xl font-bold text-slate-900">Thank You for Your Feedback</h3>
                  <p className="text-xs sm:text-sm text-slate-600 leading-relaxed max-w-sm mx-auto">
                    Your response has been received. Our management team reads every submission to continuously improve our service.
                  </p>
                </div>
                <div className="pt-3">
                  <button
                    type="button"
                    onClick={() => {
                      setSubmitted1to4(false);
                      setRating(0);
                      setComment('');
                      setCustomerName('');
                      setCustomerEmail('');
                      setCustomerPhone('');
                    }}
                    className="text-xs text-indigo-600 hover:text-indigo-700 font-bold hover:underline"
                  >
                    Submit another response
                  </button>
                </div>
              </div>
            ) : rating === 5 ? (
              /* ============================================================== */
              /* STEP 2: 5-STAR RATING FLOW */
              /* ============================================================== */
              <div className="space-y-6 animate-in fade-in duration-200 pt-2">
                {/* Rating display */}
                <div className="flex justify-center">
                  <StarRating
                    id="star-display-5"
                    rating={5}
                    onChange={(r) => setRating(r)}
                    interactive={true}
                    size="lg"
                  />
                </div>

                {/* 5-Star Customer Message */}
                <div className="p-5 rounded-2xl bg-emerald-50/70 border border-emerald-200/80 text-center space-y-2">
                  <div className="inline-flex items-center gap-1.5 text-xs font-bold text-emerald-800 bg-white px-3 py-1 rounded-full shadow-2xs border border-emerald-100 mx-auto">
                    <Sparkles className="w-3.5 h-3.5 text-emerald-600" />
                    <span>5-Star Experience</span>
                  </div>
                  <h3 className="text-base sm:text-lg font-bold text-emerald-950">
                    Thank you! We're glad you had a great experience.
                  </h3>
                  <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
                    Would you like to share your experience on Google?
                  </p>
                </div>

                {/* Leave a Google Review Button */}
                <div className="space-y-3">
                  <button
                    type="button"
                    id="leave-google-review-btn"
                    onClick={handleGoogleReviewClick}
                    disabled={redirectingGoogle}
                    className="w-full flex items-center justify-center gap-2.5 px-5 py-3.5 bg-indigo-600 hover:bg-indigo-700 active:scale-[0.99] text-white font-bold text-sm sm:text-base rounded-2xl shadow-md transition-all cursor-pointer disabled:opacity-75"
                  >
                    {redirectingGoogle ? (
                      <>
                        <Loader2 className="w-5 h-5 animate-spin" />
                        <span>Opening Google Reviews...</span>
                      </>
                    ) : (
                      <>
                        <span>Leave a Google Review</span>
                        <ExternalLink className="w-4 h-4" />
                      </>
                    )}
                  </button>

                  <p className="text-[11px] text-slate-400 text-center leading-tight">
                    You will be redirected directly to Google's official review page for {businessDisplayName}.
                  </p>
                </div>

                {googleRedirectSuccess && (
                  <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 text-center text-xs text-slate-600 space-y-1">
                    <p className="font-semibold text-slate-800">Review page opened in a new tab!</p>
                    <p className="text-[11px] text-slate-500">
                      If the window did not open,{' '}
                      <a
                        href={business.googleReviewUrl || '#'}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-indigo-600 underline font-bold"
                      >
                        click here to open Google Reviews
                      </a>.
                    </p>
                  </div>
                )}

                <div className="pt-2 text-center">
                  <button
                    type="button"
                    onClick={() => setRating(0)}
                    className="text-xs text-slate-400 hover:text-slate-600 font-medium"
                  >
                    Change rating
                  </button>
                </div>
              </div>
            ) : rating >= 1 && rating <= 4 ? (
              /* ============================================================== */
              /* STEP 2: 1-4 STARS FEEDBACK FORM */
              /* ============================================================== */
              <div className="space-y-5 animate-in fade-in duration-200 pt-1">
                {/* Interactive Star Picker */}
                <div className="text-center space-y-1 pb-1">
                  <span className="text-xs font-semibold text-slate-500">Selected Rating:</span>
                  <div className="flex justify-center">
                    <StarRating
                      id="star-picker-1-4"
                      rating={rating}
                      onChange={(r) => setRating(r)}
                      interactive={true}
                      size="lg"
                    />
                  </div>
                </div>

                {/* Empathetic Prompt */}
                <div className="p-4 rounded-2xl bg-amber-50/80 border border-amber-200/80 text-slate-800 space-y-1.5">
                  <div className="flex items-center gap-2 text-xs font-bold text-amber-900">
                    <Heart className="w-4 h-4 text-amber-600 shrink-0" />
                    <span>We value your feedback</span>
                  </div>
                  <p className="text-xs text-slate-600 leading-relaxed">
                    Please share your thoughts below so we can address any concerns directly and improve your next visit.
                  </p>
                </div>

                {/* Feedback Form */}
                <form onSubmit={handle1to4Submit} className="space-y-4">
                  {/* Rating display field */}
                  <div>
                    <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                      Rating
                    </label>
                    <div className="px-3.5 py-2.5 rounded-xl bg-slate-50 border border-slate-200 text-xs font-bold text-slate-800 flex items-center justify-between">
                      <span className="flex items-center gap-1.5">
                        <Star className="w-4 h-4 fill-amber-400 text-amber-500" />
                        <span>{rating} of 5 Stars</span>
                      </span>
                      <button
                        type="button"
                        onClick={() => setRating(0)}
                        className="text-xs text-indigo-600 hover:underline font-normal"
                      >
                        Change
                      </button>
                    </div>
                  </div>

                  {/* Comment field */}
                  <div>
                    <label htmlFor="feedback-comment" className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                      Comment <span className="text-rose-500">*</span>
                    </label>
                    <textarea
                      id="feedback-comment"
                      required
                      rows={3}
                      value={comment}
                      onChange={(e) => setComment(e.target.value)}
                      placeholder="Please tell us about your experience and how we can improve..."
                      className="w-full rounded-xl border border-slate-300 bg-white p-3 text-sm text-slate-900 placeholder:text-slate-400 focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500/20 focus:outline-none"
                    />
                  </div>

                  {/* Customer Name */}
                  <div>
                    <Input
                      id="feedback-customer-name"
                      label="Your Name (Optional)"
                      placeholder="e.g. Sarah M."
                      value={customerName}
                      onChange={(e) => setCustomerName(e.target.value)}
                    />
                  </div>

                  {/* Customer Email & Phone */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <Input
                      id="feedback-customer-email"
                      type="email"
                      label="Email (Optional)"
                      placeholder="sarah@example.com"
                      value={customerEmail}
                      onChange={(e) => setCustomerEmail(e.target.value)}
                    />
                    <Input
                      id="feedback-customer-phone"
                      type="tel"
                      label="Phone (Optional)"
                      placeholder="(555) 000-0000"
                      value={customerPhone}
                      onChange={(e) => setCustomerPhone(e.target.value)}
                    />
                  </div>

                  <Button
                    id="submit-customer-feedback-btn"
                    type="submit"
                    variant="primary"
                    className="w-full justify-center mt-2"
                    size="lg"
                    disabled={submitting || !comment.trim()}
                    leftIcon={submitting ? <Loader2 className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
                  >
                    {submitting ? 'Submitting Feedback...' : 'Send Feedback to Management'}
                  </Button>

                  <p className="text-[11px] text-slate-400 text-center leading-tight">
                    🔒 Confidential: Your feedback goes directly to {businessDisplayName}'s management team.
                  </p>
                </form>
              </div>
            ) : (
              /* ============================================================== */
              /* STEP 1: INITIAL STAR RATING SELECTION */
              /* ============================================================== */
              <div className="p-6 rounded-2xl bg-slate-50 border border-slate-200/60 text-center space-y-4">
                <div className="space-y-1">
                  <h2 className="text-lg sm:text-xl font-bold text-slate-900">
                    How was your experience with {businessDisplayName}?
                  </h2>
                  <p className="text-xs text-slate-500 max-w-xs mx-auto">
                    Please tap a star rating below to share your experience:
                  </p>
                </div>

                <div className="py-3 flex justify-center">
                  <StarRating
                    id="public-star-selector-step1"
                    rating={rating}
                    onChange={(r) => setRating(r)}
                    interactive={true}
                    size="xl"
                    showLabel={true}
                  />
                </div>
              </div>
            )}
          </div>
        </Card>
      </div>

      {/* Footer */}
      <div className="w-full max-w-lg mx-auto text-center text-xs text-slate-400 pt-6">
        <span>Powered by </span>
        <Link to="/" className="text-indigo-600 hover:underline font-semibold">
          GrowMore
        </Link>
        <span> • Direct Reputation & Customer Feedback Management</span>
      </div>
    </div>
  );
};
