import {
  collection,
  doc,
  getDoc,
  getDocs,
  setDoc,
  updateDoc,
  query,
  where,
  limit,
  serverTimestamp,
} from 'firebase/firestore';
import { ref, uploadBytes, getDownloadURL } from 'firebase/storage';
import { db, storage, auth } from '../lib/firebase';
import { Business, FirestoreBusinessData } from '../types';

export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

export interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
    isAnonymous?: boolean | null;
    tenantId?: string | null;
    providerInfo?: {
      providerId?: string | null;
      email?: string | null;
    }[];
  };
}

export function handleFirestoreError(
  error: unknown,
  operationType: OperationType,
  path: string | null
): never {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth?.currentUser?.uid || null,
      email: auth?.currentUser?.email || null,
      emailVerified: auth?.currentUser?.emailVerified || null,
      isAnonymous: auth?.currentUser?.isAnonymous || null,
      tenantId: auth?.currentUser?.tenantId || null,
      providerInfo:
        auth?.currentUser?.providerData?.map((provider) => ({
          providerId: provider.providerId,
          email: provider.email,
        })) || [],
    },
    operationType,
    path,
  };
  console.error('Firestore Error: ', JSON.stringify(errInfo));
  throw new Error(JSON.stringify(errInfo));
}

/**
 * Validates whether a string is a well-formed HTTP/HTTPS URL
 */
export function isValidUrl(urlString: string): boolean {
  if (!urlString || typeof urlString !== 'string') return false;
  try {
    const parsed = new URL(urlString.trim());
    return parsed.protocol === 'http:' || parsed.protocol === 'https:';
  } catch {
    return false;
  }
}

/**
 * Generates a clean URL-safe slug from a business name
 */
export function generateBaseSlug(businessName: string): string {
  const clean = businessName
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9\s-]/g, '')
    .replace(/\s+/g, '-')
    .replace(/-+/g, '-')
    .replace(/^-|-$/g, '');
  return clean || 'my-business';
}

/**
 * Generates a unique slug by checking against existing businesses in Firestore
 */
export async function generateUniqueSlug(
  businessName: string,
  excludeBusinessId?: string
): Promise<string> {
  const base = generateBaseSlug(businessName);
  if (!db) return base;

  let candidate = base;
  let counter = 1;

  while (counter <= 50) {
    const path = 'businesses';
    try {
      const q = query(collection(db, path), where('slug', '==', candidate), limit(1));
      const snap = await getDocs(q);

      if (snap.empty) {
        return candidate;
      }

      const match = snap.docs[0];
      if (excludeBusinessId && match.id === excludeBusinessId) {
        return candidate;
      }

      counter++;
      candidate = `${base}-${counter}`;
    } catch (error) {
      console.warn('Slug uniqueness query notice:', error);
      return counter === 1 ? base : `${base}-${Date.now().toString().slice(-4)}`;
    }
  }

  return `${base}-${Date.now().toString().slice(-4)}`;
}

/**
 * Uploads a business logo to Firebase Storage with a fallback to base64 data URL
 */
export async function uploadBusinessLogo(userId: string, file: File): Promise<string> {
  if (storage) {
    try {
      const sanitizedName = file.name.replace(/[^a-zA-Z0-9.-]/g, '_');
      const storagePath = `businesses/${userId}/logo_${Date.now()}_${sanitizedName}`;
      const storageRef = ref(storage, storagePath);
      const uploadResult = await uploadBytes(storageRef, file);
      const downloadUrl = await getDownloadURL(uploadResult.ref);
      return downloadUrl;
    } catch (storageErr) {
      console.warn('Firebase Storage upload failed, falling back to data URL:', storageErr);
    }
  }

  // Fallback: convert file to compressed Data URL
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result as string);
    reader.onerror = (err) => reject(err);
    reader.readAsDataURL(file);
  });
}

/**
 * Maps raw Firestore document data to a standard Business object
 */
export function mapDocToBusiness(id: string, data: any): Business {
  const businessName = data.businessName || data.name || 'My Business';
  const email = data.email || data.contactEmail || '';
  const slug = data.slug || generateBaseSlug(businessName);

  return {
    id,
    ownerId: data.ownerId || '',
    businessName,
    ownerName: data.ownerName || 'Business Owner',
    email,
    phone: data.phone || '',
    category: data.category || 'Local Business',
    address: data.address || '',
    website: data.website || '',
    logoUrl: data.logoUrl || '',
    googleReviewUrl: data.googleReviewUrl || '',
    googlePlaceId: data.googlePlaceId || '',
    slug,
    headerColor: data.headerColor || '#4f46e5',
    accentColor: data.accentColor || '#6366f1',
    customHeadline: data.customHeadline || `How was your experience at ${businessName}?`,
    customSubheadline:
      data.customSubheadline || 'We care about your feedback. Please take 10 seconds to share your thoughts.',
    thresholdRatingForGoogle: data.thresholdRatingForGoogle ?? 4,
    createdAt: data.createdAt ? (typeof data.createdAt.toDate === 'function' ? data.createdAt.toDate().toISOString() : String(data.createdAt)) : new Date().toISOString(),
    updatedAt: data.updatedAt ? (typeof data.updatedAt.toDate === 'function' ? data.updatedAt.toDate().toISOString() : String(data.updatedAt)) : new Date().toISOString(),
    isActive: data.isActive !== false,
    // Unified aliases
    name: businessName,
    contactEmail: email,
    plan: data.plan || 'starter',
    status: data.status || 'active',
    stats: data.stats || {
      totalFeedback: 0,
      averageRating: 5,
      fiveStarCount: 0,
      googleClicks: 0,
    },
  };
}

/**
 * Fetch a business by its owner ID from Firestore
 */
export async function getBusinessByOwnerId(ownerId: string): Promise<Business | null> {
  if (!db || !ownerId) return null;
  const path = 'businesses';

  try {
    const q = query(collection(db, path), where('ownerId', '==', ownerId), limit(1));
    const snap = await getDocs(q);

    if (snap.empty) {
      // Also check if document ID equals ownerId
      const directDocRef = doc(db, path, ownerId);
      const directSnap = await getDoc(directDocRef);
      if (directSnap.exists()) {
        return mapDocToBusiness(directSnap.id, directSnap.data());
      }
      return null;
    }

    const firstDoc = snap.docs[0];
    return mapDocToBusiness(firstDoc.id, firstDoc.data());
  } catch (error) {
    handleFirestoreError(error, OperationType.GET, path);
  }
}

/**
 * Fetch a public business by its unique URL slug
 */
export async function getBusinessBySlug(slug: string): Promise<Business | null> {
  if (!slug) return null;

  if (db) {
    const path = 'businesses';
    try {
      const q = query(
        collection(db, path),
        where('slug', '==', slug.toLowerCase().trim()),
        limit(1)
      );
      const snap = await getDocs(q);

      if (!snap.empty) {
        const firstDoc = snap.docs[0];
        const data = firstDoc.data();
        if (data.isActive !== false) {
          return mapDocToBusiness(firstDoc.id, data);
        }
      }
    } catch (error) {
      console.warn('Error fetching business by slug from Firestore:', error);
    }
  }

  // Check locally saved business if in demo/offline session
  try {
    const local = localStorage.getItem('reviewflow_auth_biz');
    if (local) {
      const parsed = JSON.parse(local);
      if (parsed && (parsed.slug === slug || parsed.id === slug)) {
        return mapDocToBusiness(parsed.id, parsed);
      }
    }
  } catch {}

  return null;
}

/**
 * Create a new business profile in Firestore
 */
export interface CreateBusinessInput {
  ownerId: string;
  businessName: string;
  ownerName: string;
  email: string;
  phone?: string;
  category: string;
  address?: string;
  website?: string;
  googleReviewUrl: string;
  googlePlaceId?: string;
  logoFile?: File | null;
  existingLogoUrl?: string;
}

export async function createBusinessProfile(input: CreateBusinessInput): Promise<Business> {
  if (!input.ownerId) throw new Error('Owner ID is required to create a business profile.');
  if (!input.businessName?.trim()) throw new Error('Business Name is required.');
  if (!input.googleReviewUrl?.trim()) throw new Error('Google Review URL is required.');
  if (!isValidUrl(input.googleReviewUrl)) throw new Error('Please enter a valid Google Review URL (http:// or https://).');
  if (input.website && !isValidUrl(input.website)) {
    throw new Error('Please enter a valid Website URL (e.g. https://yourbusiness.com).');
  }

  let finalLogoUrl = input.existingLogoUrl || '';
  if (input.logoFile) {
    finalLogoUrl = await uploadBusinessLogo(input.ownerId, input.logoFile);
  }

  const uniqueSlug = await generateUniqueSlug(input.businessName);

  const businessId = `biz_${input.ownerId.slice(0, 8)}_${Date.now().toString().slice(-4)}`;
  const nowIso = new Date().toISOString();

  const businessPayload: FirestoreBusinessData = {
    ownerId: input.ownerId,
    businessName: input.businessName.trim(),
    ownerName: input.ownerName.trim() || 'Owner',
    email: input.email.trim(),
    phone: input.phone?.trim() || '',
    category: input.category || 'Local Business',
    address: input.address?.trim() || '',
    website: input.website?.trim() || '',
    logoUrl: finalLogoUrl,
    googleReviewUrl: input.googleReviewUrl.trim(),
    googlePlaceId: input.googlePlaceId || '',
    slug: uniqueSlug,
    headerColor: '#4f46e5',
    accentColor: '#6366f1',
    customHeadline: `How was your experience at ${input.businessName.trim()}?`,
    customSubheadline: 'We care about your feedback. Please take 10 seconds to share your thoughts.',
    thresholdRatingForGoogle: 4,
    createdAt: nowIso,
    updatedAt: nowIso,
    isActive: true,
  };

  if (db) {
    const docPath = `businesses/${businessId}`;
    try {
      const docRef = doc(db, 'businesses', businessId);
      await setDoc(docRef, {
        ...businessPayload,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, docPath);
    }
  }

  const createdBusiness = mapDocToBusiness(businessId, businessPayload);

  // Save to local storage for immediate offline hydration
  try {
    localStorage.setItem('reviewflow_auth_biz', JSON.stringify(createdBusiness));
  } catch {}

  return createdBusiness;
}

/**
 * Update an existing business profile in Firestore
 */
export interface UpdateBusinessInput {
  businessName?: string;
  ownerName?: string;
  phone?: string;
  address?: string;
  website?: string;
  category?: string;
  email?: string;
  googleReviewUrl?: string;
  googlePlaceId?: string;
  headerColor?: string;
  accentColor?: string;
  customHeadline?: string;
  customSubheadline?: string;
  thresholdRatingForGoogle?: number;
  logoFile?: File | null;
  logoUrl?: string;
}

export async function updateBusinessProfile(
  businessId: string,
  ownerId: string,
  updates: UpdateBusinessInput
): Promise<Business> {
  if (!businessId) throw new Error('Business ID is required for update.');

  if (updates.googleReviewUrl && !isValidUrl(updates.googleReviewUrl)) {
    throw new Error('Please enter a valid Google Review URL (http:// or https://).');
  }
  if (updates.website && updates.website.trim() && !isValidUrl(updates.website)) {
    throw new Error('Please enter a valid Website URL (e.g. https://yourbusiness.com).');
  }

  let finalLogoUrl = updates.logoUrl;
  if (updates.logoFile) {
    finalLogoUrl = await uploadBusinessLogo(ownerId, updates.logoFile);
  }

  const payload: Partial<FirestoreBusinessData> = {
    updatedAt: new Date().toISOString(),
  };

  if (updates.businessName !== undefined) payload.businessName = updates.businessName.trim();
  if (updates.ownerName !== undefined) payload.ownerName = updates.ownerName.trim();
  if (updates.phone !== undefined) payload.phone = updates.phone.trim();
  if (updates.address !== undefined) payload.address = updates.address.trim();
  if (updates.website !== undefined) payload.website = updates.website.trim();
  if (updates.category !== undefined) payload.category = updates.category;
  if (updates.email !== undefined) payload.email = updates.email.trim();
  if (updates.googleReviewUrl !== undefined) payload.googleReviewUrl = updates.googleReviewUrl.trim();
  if (updates.googlePlaceId !== undefined) payload.googlePlaceId = updates.googlePlaceId;
  if (updates.headerColor !== undefined) payload.headerColor = updates.headerColor;
  if (updates.accentColor !== undefined) payload.accentColor = updates.accentColor;
  if (updates.customHeadline !== undefined) payload.customHeadline = updates.customHeadline;
  if (updates.customSubheadline !== undefined) payload.customSubheadline = updates.customSubheadline;
  if (updates.thresholdRatingForGoogle !== undefined) payload.thresholdRatingForGoogle = updates.thresholdRatingForGoogle;
  if (finalLogoUrl !== undefined) payload.logoUrl = finalLogoUrl;

  if (db) {
    const docPath = `businesses/${businessId}`;
    try {
      const docRef = doc(db, 'businesses', businessId);
      await updateDoc(docRef, {
        ...payload,
        updatedAt: serverTimestamp(),
      });
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, docPath);
    }
  }

  // Get current local business and merge
  let merged: Business;
  try {
    const local = localStorage.getItem('reviewflow_auth_biz');
    const existing = local ? JSON.parse(local) : {};
    merged = mapDocToBusiness(businessId, { ...existing, ...payload });
    localStorage.setItem('reviewflow_auth_biz', JSON.stringify(merged));
  } catch {
    merged = mapDocToBusiness(businessId, payload);
  }

  return merged;
}
